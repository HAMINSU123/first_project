package com.green.nottodolistlist.useList.model;

import lombok.Data;

@Data
public class UseListInsDto {
    private int goalId;
    private String date;
}
