package com.green.nottodolistlist.daily;

import com.green.nottodolistlist.daily.model.DailyDelDto;
import com.green.nottodolistlist.daily.model.DailySelDto;
import com.green.nottodolistlist.daily.model.DailyUpdDto;
import com.green.nottodolistlist.daily.model.DailyVo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface DailyMapper {
    int delDaily(DailyDelDto dto);

    int updDaily(DailyUpdDto dto);

    List<DailyVo> selDailyAll(DailySelDto dto);

    Integer selDailyUseCost(int useListId);
}
