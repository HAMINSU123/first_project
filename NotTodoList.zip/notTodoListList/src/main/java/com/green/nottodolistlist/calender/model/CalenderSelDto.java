package com.green.nottodolistlist.calender.model;

import lombok.Data;

@Data
public class CalenderSelDto {
    private int memberId;
    private String monthYear;
}
