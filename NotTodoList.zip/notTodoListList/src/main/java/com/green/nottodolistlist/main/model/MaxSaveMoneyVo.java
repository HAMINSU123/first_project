package com.green.nottodolistlist.main.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class MaxSaveMoneyVo {
    private String monthYear;
    private String maxSaveMoney;
}
