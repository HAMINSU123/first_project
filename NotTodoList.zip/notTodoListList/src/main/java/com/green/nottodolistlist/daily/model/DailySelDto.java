package com.green.nottodolistlist.daily.model;

import lombok.Data;

@Data
public class DailySelDto {
    private int memberId;
    private String date;
}
