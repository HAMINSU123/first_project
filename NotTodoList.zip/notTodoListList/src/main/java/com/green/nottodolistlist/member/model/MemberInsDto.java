package com.green.nottodolistlist.member.model;

import lombok.Data;

@Data
public class MemberInsDto {
    private String nickname;
}
