package com.green.nottodolistlist.monthlyGoal.model;

import lombok.Data;

@Data
public class NotTodoEntity {
    private int notTodoId;
    private String name;
}
