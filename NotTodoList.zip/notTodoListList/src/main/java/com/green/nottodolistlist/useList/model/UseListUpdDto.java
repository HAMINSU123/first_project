package com.green.nottodolistlist.useList.model;

import lombok.Data;

@Data
public class UseListUpdDto {
    private int goalId;
    private int useCost;
}
