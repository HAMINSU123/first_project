package com.green.nottodolistlist.main;

import com.green.nottodolistlist.main.model.SaveCostDataVo;
import com.green.nottodolistlist.member.MemberMapper;
import com.green.nottodolistlist.member.model.MemberEntity;
import com.green.nottodolistlist.member.model.MemberInsDto;
import com.green.nottodolistlist.member.model.MemoUpdDto;
import com.green.nottodolistlist.monthlyGoal.MonthlyGoalMapper;
import com.green.nottodolistlist.monthlyGoal.model.MonthDto;
import com.green.nottodolistlist.monthlyGoal.model.MonthlyGoalVo;
import com.green.nottodolistlist.useList.UseListMapper;
import com.green.nottodolistlist.useList.model.UseListUpdDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MainService {
    private final UseListMapper useListMapper;
    private final MonthlyGoalMapper monthlyGoalMapper;
    private final MemberMapper memberMapper;

    public int updUseList(UseListUpdDto dto) {
        monthlyGoalMapper.updSaveCost(dto);
        return useListMapper.updUseList(dto);
    }

    public List<MonthlyGoalVo> selTodayGoal(int memberId){
        List<MonthlyGoalVo> list = monthlyGoalMapper.selMonthlyGoal(memberId);
        for (MonthlyGoalVo vo : list) {
            vo.setCostCategory(vo.getCostCategoryId() == 1 ? "원" : "시간");
        }
        return list;
    }

    public SaveCostDataVo selSaveCostData(MonthDto dto){
        return new SaveCostDataVo(
                monthlyGoalMapper.selMaxSaveMoney(dto.getMemberId()),
                monthlyGoalMapper.selMaxSaveTime(dto.getMemberId()),
                monthlyGoalMapper.selSumSaveMoney(dto),
                monthlyGoalMapper.selSumSaveTime(dto));
    }

    public int insMember(MemberInsDto dto) {
        MemberEntity entity = new MemberEntity();
        entity.setNickname(dto.getNickname());
        memberMapper.insMember(entity);

        return entity.getMemberId();
    }

    public String selMember(int memberId) {
        return memberMapper.selMember(memberId);
    }

    public String selMemo(int memberId) {
        return memberMapper.selMemo(memberId);
    }

    public int updMemo(MemoUpdDto dto) {
        return memberMapper.updMemo(dto);
    }
}
