package com.green.nottodolistlist.calender;

import com.green.nottodolistlist.calender.model.CalenderSelDto;
import com.green.nottodolistlist.calender.model.CalenderSelVo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CalenderMapper {
    List<CalenderSelVo> selCalender(CalenderSelDto dto);
}
