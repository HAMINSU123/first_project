package com.green.nottodolistlist.daily.model;

import lombok.Data;

@Data
public class DailyDelDto {
    private int useListId;
}
