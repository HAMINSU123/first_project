package com.green.nottodolistlist.useList;


import com.green.nottodolistlist.useList.model.UseListInsDto;
import com.green.nottodolistlist.useList.model.UseListUpdDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UseListMapper {
    int insUseList(List<UseListInsDto> dto);
    int updUseList(UseListUpdDto dto);

}
