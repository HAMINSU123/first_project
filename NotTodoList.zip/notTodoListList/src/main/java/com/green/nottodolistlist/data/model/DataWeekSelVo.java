package com.green.nottodolistlist.data.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class DataWeekSelVo {
    private String name;
    private String cost;
}
