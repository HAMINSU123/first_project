package com.green.nottodolistlist.monthlyGoal;

import com.green.nottodolistlist.main.model.MaxSaveMoneyVo;
import com.green.nottodolistlist.main.model.MaxSaveTimeVo;
import com.green.nottodolistlist.monthlyGoal.model.*;
import com.green.nottodolistlist.useList.model.UseListUpdDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MonthlyGoalMapper {
    int insMonthlyGoal(MonthlyGoalEntity entity);

    int updMonthlyGoal(MonthlyGoalEntity entity);

    int insNotTodo(NotTodoEntity entity);

    List<MonthlyGoalVo> selMonthlyGoal(int memberId);
    List<MonthlyGoalDetailVo> selMonthlyGoalAll(int memberId);

    Integer selNotTodoId(String name);

    int delMonthlyGoal(int goalId);

    MaxSaveMoneyVo selMaxSaveMoney(int memberId);

    MaxSaveTimeVo selMaxSaveTime(int memberId);

    String selSumSaveMoney(MonthDto dto);

    String selSumSaveTime(MonthDto dto);

    int updSaveCost(UseListUpdDto dto);
}
