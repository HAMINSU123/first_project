package com.green.nottodolistlist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotTodoListListApplication {
    public static void main(String[] args) {
        SpringApplication.run(NotTodoListListApplication.class, args);
    }
}
