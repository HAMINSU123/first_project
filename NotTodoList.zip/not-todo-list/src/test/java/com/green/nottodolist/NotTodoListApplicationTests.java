package com.green.nottodolist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotTodoListApplicationTests {

	@Test
	void contextLoads() {
	}

}
