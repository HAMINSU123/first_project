package com.green.nottodolist.data.model;

import lombok.Data;

@Data
public class DataCostVo {
    private String month;
    private String saveCost;
}
