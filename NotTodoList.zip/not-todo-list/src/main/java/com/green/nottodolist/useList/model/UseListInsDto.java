package com.green.nottodolist.useList.model;

import lombok.Data;

@Data
public class UseListInsDto {
    private int goalId;
    private String date;
}
