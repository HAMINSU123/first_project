package com.green.nottodolist.useList.model;

import lombok.Data;

@Data
public class UseListUpdDto {
    private int goalId;
    private int useCost;
}
