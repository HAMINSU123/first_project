package com.green.nottodolist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotTodoListApplication {
    public static void main(String[] args) {
        SpringApplication.run(NotTodoListApplication.class, args);
    }
}
