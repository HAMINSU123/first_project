package com.green.nottodolist.monthlyGoal.model;

import lombok.Data;

@Data
public class NotTodoEntity {
    private int notTodoId;
    private String name;
}
