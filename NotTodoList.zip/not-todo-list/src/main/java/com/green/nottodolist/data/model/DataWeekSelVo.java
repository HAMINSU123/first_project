package com.green.nottodolist.data.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class DataWeekSelVo {
    private String name;
    private String cost;
}
