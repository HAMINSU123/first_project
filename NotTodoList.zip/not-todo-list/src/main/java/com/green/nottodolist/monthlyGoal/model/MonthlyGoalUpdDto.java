package com.green.nottodolist.monthlyGoal.model;

import lombok.Data;

@Data
public class MonthlyGoalUpdDto {
    private int goalId;
    private int goalCost;
}
