package com.green.nottodolist.calender.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class CalenderSelVo {
    private String name;
    private String date;
}
