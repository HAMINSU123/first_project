package com.green.nottodolist.daily.model;

import lombok.Data;

@Data
public class DailyUpdDto {
    private int useListId;
    private int goalId;
    private int useCost;
}
