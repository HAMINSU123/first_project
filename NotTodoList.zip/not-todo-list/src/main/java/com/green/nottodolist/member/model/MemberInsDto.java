package com.green.nottodolist.member.model;

import lombok.Data;

@Data
public class MemberInsDto {
    private String nickname;
}
