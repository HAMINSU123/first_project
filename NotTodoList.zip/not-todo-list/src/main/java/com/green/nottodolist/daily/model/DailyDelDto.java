package com.green.nottodolist.daily.model;

import lombok.Data;

@Data
public class DailyDelDto {
    private int useListId;
}
