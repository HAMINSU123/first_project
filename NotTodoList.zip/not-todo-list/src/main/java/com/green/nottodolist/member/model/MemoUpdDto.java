package com.green.nottodolist.member.model;

import lombok.Data;

@Data
public class MemoUpdDto {
    private int memberId;
    private String memo;
}
