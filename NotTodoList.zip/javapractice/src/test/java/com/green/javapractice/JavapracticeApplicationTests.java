package com.green.javapractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavapracticeApplicationTests {

    @Test
    void contextLoads() {
    }

}
