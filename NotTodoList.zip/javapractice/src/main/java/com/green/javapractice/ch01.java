package com.green.javapractice;



import java.util.Scanner;

public class ch01 {
    public static void main(String[] args) {


    }
}
