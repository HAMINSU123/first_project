package com.green.javapractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavapracticeApplication {

    public static void main(String[] args) {
        SpringApplication.run(JavapracticeApplication.class, args);
    }

}
